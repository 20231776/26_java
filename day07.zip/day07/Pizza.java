package day07;

// Circle
class Circle {
	public String name;
	public int radius;

	/*	public Circle() {
		radius = 10;
		name = "불고기피자";
		
	}
	
	public Circle(int r, String n) {
		radius = r;
		name = n;
	} */
	
	public Circle() {
		this(0, "");
	}
	
	public Circle(int radius) {
		this(radius, "");
	}
	
	public Circle(int radius, String name) {
		this.radius = radius;
		this.name = name;
	}
	
	public double getArea() {
		return 3.14 * radius * radius;
	}
}

public class Pizza {

	public static void main(String[] args) {
		// 1. 레퍼런스 변수 pizza 선언
		Circle pizza;
		// Circle pizza2;
		
		// 2. Circle 객체 생성
		pizza = new Circle();
		// pizza2 = new Circle(10,"치즈피자");
		
		// 3. 피자 반지름 10으로 설정.
		// pizza.radius = 10;
		
		// 4. 피자의 이름을 불고기피자로 설정
		// pizza.name = "불고기피자";
		
		// 5. 피자의 면적 메소드 호출하여 알아내기
		System.out.println(pizza.name + "의 원의 면적은 " + pizza.getArea());
		// System.out.println(pizza2.name);
		
		Circle donut;
		donut = new Circle();
		donut.radius = 5;
		donut.name = "자바도넛";
		System.out.println(donut.name + "의 면적은 " + donut.getArea());
	}
}