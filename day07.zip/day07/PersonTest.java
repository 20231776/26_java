package day07;

public class PersonTest {

	public static void main(String[] args) {
		// Person 객체 생성
		/*
		Person Jang = new Person();
		Jang.name = "장발장";
		Jang.age = 23;
		Jang.abc = 'B';
		Jang.밥먹기();
		Jang.운동하기("복싱");		
*/		
		Person hong = new Person();
		hong.밥먹기();
		hong.운동하기("헬스");
		
	//	hong.addr = "대전동구 용운동";
		
		System.out.println(Person.getName()); // static 메소드호출은 클래스이름. 으로 사용가능
		
	}

}
