package day07;
import java.util.Scanner;

public class Book {
	String title, author;
	
	public Book(String title, String author) {
		this.title = title;
		this.author = author;
	}

	/*	
	public Book(String t) {
		title = t;
		author = "작자미상";
	}
	*/
	
	public static void main(String[] args) {	
	
		Book[] book = new Book[2];
		Scanner scanner = new Scanner(System.in);
		
		for (int i = 0; i < book.length; i++) {
			System.out.print("제목을 입력하세요 : ");
			String title = scanner.nextLine();
			System.out.print("저자를 입력하세요 : >");
			String author = scanner.nextLine();
			book[i] = new Book(title, author);
		}
		
		/*	
		Book littlePrince = new Book("어린왕자","생텍쥐페리");
		Book loveStory = new Book("춘향전");		
		System.out.println(littlePrince.title + " " + littlePrince.author);
		System.out.println(loveStory.title + " " + loveStory.author);
		*/		
		
		for (int i = 0; i < book.length; i++) {
			System.out.print("제목은 " + book[i].title + "이고, 저자는 " + book[i].author + "이다.\n");
		}
		
		scanner.close();
	}
}