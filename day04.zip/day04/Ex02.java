package day04;
import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("필기시험 점수를 입력하세요:");
		System.out.println("토익시험 점수를 입력하세요:");
		int score = scanner.nextInt();
		int toeic = scanner.nextInt();
		
		if (score >= 80 && toeic >= 850) {
			System.out.println("합격입니다.");
		} else {
			
			System.out.println("불합격입니다.");
		}

		
		scanner.close();
	}

}
