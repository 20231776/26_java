package day04;
import java.util.Scanner;
public class Ex07 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		int sum = 0;
		System.out.println("정수를 입력하세요:");
		
		for (int i = 0 ; i <= 5 ; i++) {
			int num = scanner.nextInt();
			
			if(num <= 0) 
				continue;
			else {
				sum = sum + num;
			}
			
		}
		System.out.println("양수의 합은 :" + sum);
	
		scanner.close();
	}

}
