package day04;

public class Ex05 {

	public static void main(String[] args) {
		int i = 1;
		int sum = 0;
		while (i <= 100) {
			sum = sum + i;
			i++;
		}
		System.out.print(sum);
	}
}
