package day06;
import java.util.Scanner;
public class Overloading {

	public static void coffee(int c) { // 블랙커피
		System.out.println("블랙 커피를 만듭니다");
	}
	public static void coffee(int c, int cr) { // 크림커피
		System.out.println("크림 커피를 만듭니다");
	}
	public static void coffee(int c, int cr, int sg) { // 믹스커피
		System.out.println("믹스 커피를 만듭니다");
		}
	
	
	public static void main(String[] args) {
		coffee(10);

	}
}
