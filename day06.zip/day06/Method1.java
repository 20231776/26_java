package day06;
import java.util.Scanner;

public class Method1 {
	// 1. 매개변수 X, 반환형도 X add메소드
	public static void add() {
		Scanner scanner = new Scanner(System.in);
		int num1 = scanner.nextInt();
		int num2 = scanner.nextInt();
		System.out.println(num1 + num2);
		scanner.close();
	}
	// 2. 매개변수 O, 반환형은 X add메소드
	public static void add(int a, int b) {
		System.out.println(a + b);
	}
	
	// 3. 매개변수 x, 반환형은 O add메소드
	public static int add1() {
		Scanner scanner = new Scanner(System.in);
		int num = scanner.nextInt();
		int num2 = scanner.nextInt();
		return num + num2;
		}
	// 4. 매개변수와 반환형 둘다 O add메소드
	public static int add2(int a, int b) {
		return a+b;
	}
	
	public static void main(String[] args) {
		//add();
		//add(50, 60);
		//System.out.println(add1());
		// 호출
		int result = add2(50, 70);
		System.out.println(result);
		
	}

}
