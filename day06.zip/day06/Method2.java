package day06;
import java.util.Scanner;
public class Method2 {

	public static void max() {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("정수 두 개를 입력해주세요. 최대값이 반환됩니다.");
		int num1 = scanner.nextInt();
		int num2 = scanner.nextInt();
		
		if(num1 > num2) {
			System.out.println(num1);
		} else {
			System.out.println(num2);
		}
		
		scanner.close();
	}
	
	public static void main(String[] args) {
		max();
		
	}

}
