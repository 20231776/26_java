package day06;
import java.util.Scanner;
public class Add {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("2개의 실수를 입력하세요");
		double a = scanner.nextDouble();
		double b = scanner.nextDouble();
		double c = a * b;
		System.out.println("2개의 실수의 곱은 " + c + "입니다.");
		
		
		scanner.close();
	}
	
}
