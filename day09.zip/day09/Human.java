package day09;

public class Human extends Animal{
	
	private String addr;

	public Human() {
		
	}
	public Human(String name, int age) {
		super(name, age);
	}
	
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) { // 멤버값을 저장하는 setter 메소드
		this.addr = addr;
	}

	public static void main(String[] args) {
		

	}
}
