package day10;

public class CCTV {
	private	String resolution;
	
	public CCTV(String resolution) {
		this.resolution	= resolution;
		}
	
	protected String getResolution() {
		return resolution;
		}

	public static void main(String[] args) {

	}

}

