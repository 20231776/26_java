package day10;

public class Tri extends Shape{

	@Override
	public void draw() {
		System.out.println("삼각형을 그리다.");
	}

}
