package com.market.main;
import java.util.Scanner;
import java.util.Date;
import java.text.SimpleDateFormat;
import com.market.bookitem.Book;
import com.market.cart.Cart;
import com.market.member.Admin;
import com.market.member.User;
import com.market.exception.CartException;

public class Welcome {

	
	static final int NUM_BOOK = 3;
	static final int NUM_ITEM = 7;
	static Cart mCart = new Cart();
    static User mUser;
    

    
    
    public static boolean isCartInBook(String bookId) {
    	return mCart.isCartInBook(bookId);
    }
    
	public static void BookList(Book[] bookList) {
        bookList[0] = new Book("ISBN1234", "쉽게 배우는 JSP 웹 프로그래밍", 27000);
        bookList[0].setAuthor("송미영");
        bookList[0].setDescription("단계별로 쇼핑몰을 구현하며 배우는 JSP 웹 프로그래밍");
        bookList[0].setCategory("IT전문서");
        bookList[0].setReleaseDate("2018/10/08");

        bookList[1] = new Book("ISBN1235", "안드로이드 프로그래밍", 33000);
        bookList[1].setAuthor("우재남");
        bookList[1].setDescription("실습 단계별 명쾌한 멘토링!");
        bookList[1].setCategory("IT전문서");
        bookList[1].setReleaseDate("2022/01/22");

        bookList[2] = new Book("ISBN1236", "스크래치", 22000);
        bookList[2].setAuthor("고광일");
        bookList[2].setDescription("컴퓨팅 사고력을 키우는 블록 코딩");
        bookList[2].setCategory("컴퓨터입문");
        bookList[2].setReleaseDate("2019/06/10");
    }

	
	public static void menuGuestInfo(String userName, String userMobile) { // 고객 정보 확인하기
		System.out.println("현재 고객 정보 : ");
	//	System.out.println("이름 " + userName + "\t" + "연락처 " + userMobile);
		System.out.println("이름 " + mUser.getName() + "\t" + "연락처 " + mUser.getMobile());
	}
	
	public static void menuCartItemList() { // 장바구니 상품 목록보기
		if (mCart.mCartCount >= 0) {
			mCart.printCart();
		}
	}
	
	public static void menuCartClear() throws CartException { // 장바구니 비우기
		// System.out.println("3. 장바구니 비우기");
		if (mCart.mCartCount == 0) {
			throw new CartException("장바구니에 항목이 없습니다.");
		} else {
			System.out.println("장바구니의 모든 항목을 삭제하겠습니까? Y | N");
			Scanner scanner = new Scanner(System.in);
			String str = scanner.nextLine();
			
			if (str.toUpperCase().equals("Y")) {
				mCart.deleteBook();
				System.out.println("장바구니의 모든 항목을 삭제했습니다.");
				}
			}
		}

	public static void menuCartAddItem(Book[] bookList) { // 장바구니에 항목 추가하기
		//System.out.println("4. 장바구니에 항목 추가하기");
		BookList(bookList);
		mCart.printBookList(bookList);
		boolean quit = false;
		
        while (!quit) {
            System.out.print("장바구니에 추가할 도서의 ID를 입력하세요 : ");
            Scanner scanner = new Scanner(System.in);
            String str = scanner.nextLine();
            boolean flag = false;
            int numId = -1;
            for (int i = 0; i < NUM_BOOK; i++) {
                if (str.equals(bookList[i].getBookId())) {
                    numId = i;
                    flag = true;
                    break;
                }
            }
                if (flag) {
                    System.out.println("장바구니에 추가하겠습니까? Y | N");
                    str = scanner.nextLine();
                    
                    if (str.toUpperCase().equals("Y")) {
                    	System.out.println(bookList[numId].getBookId() + " 도서가 장바구니에 추가되었습니다.");
                    }
                    quit = true;
            } else 
            	System.out.println("다시 입력해주세요.");
            }
            }
	public static void menuCartRemoveItemCount() { // 장바구니의 항목 수량 줄이기
		//System.out.println("5. 장바구니의 항목 수량 줄이기");
		try {
            if (mCart.mCartCount == 0) {
                throw new CartException("장바구니에 항목이 없습니다.");
            }
            menuCartItemList();
            Scanner scanner = new Scanner(System.in);
            System.out.print("수량을 줄일 도서 ID를 입력하세요 : ");
            String bookId = scanner.nextLine();

            for (int i = 0; i < mCart.mCartCount; i++) {
                if (bookId.equals(mCart.mCartItem.get(i).getBookId())) {
                    int quantity = mCart.mCartItem.get(i).getQuantity();
                    if (quantity > 1) {
                        mCart.mCartItem.get(i).setQuantity(quantity - 1);
                        System.out.println("수량을 1 줄였습니다.");
                    } else {
                        mCart.removeCart(i);
                        System.out.println("수량이 1개였기 때문에 항목을 삭제했습니다.");
                    }
                    return;
                }
            }
            System.out.println("해당 도서 ID가 장바구니에 없습니다.");
        } catch (CartException e) {
            System.out.println(e.getMessage());
        }
    }


	public static void menuCartRemoveItem(Book[] bookList) throws CartException{ // 장바구니의 항목 삭제하기
		// System.out.println("6. 장바구니의 항목 삭제하기");
		if (mCart.mCartCount == 0) {
			throw new CartException("장바구니에 항목이 없습니다.");
			} else {
				menuCartItemList();
				boolean quit = false;
				while (!quit) {
					System.out.print("장바구니에서 삭제할 도서의 ID를 입력하세요 : ");
					Scanner scanner = new Scanner(System.in);
					String str = scanner.nextLine();
						
					boolean flag = false;
					int numId = -1;
					
					for (int i = 0; i < NUM_BOOK; i++) {
						if (str.equals(bookList[i].getBookId())) {
							numId = i;
							flag = true;
							break;
						}
	            }

					if (flag) {
						System.out.println("장바구니의 항목을 삭제하겠습니까? Y | N");
						str = scanner.nextLine();
						if (str.toUpperCase().equals("Y")) { 
							System.out.println(bookList[numId].getBookId() + " 장바구니에서 도서가 삭제되었습니다.");
							mCart.removeCart(numId);
							
							if (!isCartInBook(bookList[numId].getBookId())) {
								mCart.insertBook(bookList[numId]);
							}
						}
						quit = true;
						} else {
							System.out.println("다시 입력해 주세요.");
							}
					}
				}
	}

	public static void menuCartbill() throws CartException{ // 영수증 표시하기
		//System.out.println("7. 영수증 표시하기");
		if(mCart.mCartCount == 0) {
			throw new CartException("장바구니에 항목이 없습니다.");
		} else {
			System.out.println("배송받을 분은 고객 정보와 같습니까? Y | N");
			Scanner scanner = new Scanner(System.in);
			String str = scanner.nextLine();
			printBill(mUser.getName(), String.valueOf(mUser.getMobile()), mUser.getAddr());
			
			if (str.toUpperCase().equals("Y")) {
				System.out.println("배송지를 입력해주세요. ");
				String addr = scanner.nextLine();
			} else {
				System.out.println("배송받을 고객명을 입력해주세요");
				String name = scanner.nextLine();
				System.out.println("배송받을 고객의 연락처를 입력해주세요");
				String mobile = scanner.nextLine();
				System.out.println("배송받을 배송지를 입력해주세요");
				String addr = scanner.nextLine();
			}
		}
	}
	
	public static void printBill(String name, String mobile, String addr) {
		
	Date date = new Date();
	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	String strDate = formatter.format(date);
	System.out.println();
	System.out.println("----------------배송받을 고객 정보----------------");
	System.out.println("고객명 : " + name +" t\t연락처 : " + mobile);
	System.out.println("배송지 : " + addr +" t\t발송일 : " + strDate);
	
	mCart.printCart();
	
	int sum = 0;
	for (int i = 0 ; i < mCart.mCartCount ; i ++) 
		sum += mCart.mCartItem.get(i).getTotalPrice();
	
	System.out.println("\t\t\t주문 총금액 : " + sum +"원\n");
	System.out.println("------------------------------------------------");
	System.out.println();
		
	}
	
	
	public static void menuExit() { // 종료
		System.out.println("8. 종료");
	}
	public static void menuAdminLogin() { //관리자 로그인
		Scanner scanner = new Scanner(System.in);
		Admin admin = new Admin("관리자", "01097781284");
		System.out.println("관리자 정보를 입력하세요.");
		System.out.print("아이디 : ");
		String adminId = scanner.nextLine();
		System.out.print("비밀번호 : ");
		String adminPw = scanner.nextLine();
		
		if (adminId.equals(admin.getId()) && adminPw.equals(admin.getPasswd())) {
			System.out.println("관리자 이름 : " + admin.getName() + "\t연락처 : " + admin.getMobile());
			System.out.println("아이디 : " + admin.getId() + "\t비밀번호 : " + admin.getPasswd());
		} else {
			System.out.println("관리자 정보가 일치하지 않습니다.");
		}
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("당신의 이름을 입력하세요 : ");
		String userName = scanner.nextLine();
		System.out.println("연락처를 입력하세요 : ");
		String userMobile = scanner.nextLine();
		
		mUser = new User(userName, userMobile);
		
		String greeting = "Welcome to shopping Mall";
		String tagline = "Welcome to Book Market!";
		boolean quit = false;
		Book[] bookList = new Book[NUM_BOOK];
		BookList(bookList);
		while (!quit) {
			System.out.println("*************************");
			System.out.println("\t" + greeting);
			System.out.println("\t" + tagline);
			/*System.out.println("*************************");
			System.out.println("1. 고객 정보 확인하기 \t4. 바구니에 항목 추가하기");
			System.out.println("2. 장바구니 상품 목록 보기 \t5. 장바구니의 항목 수량 줄이기");
			System.out.println("3. 장바구니 비우기 \t6. 장바구니의 항목 삭제하기");
			System.out.println("7. 영수증 표시하기 \t8. 종료");
			System.out.println("*************************");*/
			
			menuIntroduction();
			try {	
			System.out.println("메뉴를 선택해 주세요");
			int n = scanner.nextInt();
			if (n < 1 || n > 9) {
				System.out.println("1부터 9까지의 숫자를 입력하세요.");
			} else {
				switch (n) {
				
				case 1:
					/*System.out.println("현재 고객 정보 : ");
					System.out.println("이름 " + userName + "\t" + "연락처 " + userMobile);
					*/
					menuGuestInfo(userName, userMobile);
					break;
					
				case 2:
					//System.out.println("2.장바구니 상품 목록 보기 :");
					menuCartItemList();
					break;
				
				case 3:
					//System.out.println("3. 장바구니 비우기");
					menuCartClear();
					break;
						
				case 4:
					//System.out.println("4. 바구니에 항목 추가하기");
					menuCartAddItem(bookList);
					break;
				case 5:
					//System.out.println("5. 장바구니에 항목 수량 줄이기");
					menuCartRemoveItemCount();
					break;
					
				case 6:
					//System.out.println("6. 장바구니에 항목 삭제하기");
					menuCartRemoveItem(bookList);
					break;
					
				case 7:
					//System.out.println("7. 영수증 표시하기");
					menuCartbill();
					break;
					
				case 8:
					//System.out.println("8. 종료");
					menuExit();
					quit = true;
					break;
					
				case 9:
					menuAdminLogin();
					break;
				}
			}
			}
			catch(CartException e) {
				System.out.println(e.getMessage());
				quit = true;
			}
			catch(Exception e) {
				System.out.println("올바르지 않은 메뉴 선택으로 종료합니다");
				quit = true;
			}
	}
	}
	public static void menuIntroduction() {
		System.out.println("*************************");
		System.out.println("1. 고객 정보 확인하기 \t4. 바구니에 항목 추가하기");
		System.out.println("2. 장바구니 상품 목록 보기 \t5. 장바구니의 항목 수량 줄이기");
		System.out.println("3. 장바구니 비우기 \t6. 장바구니의 항목 삭제하기");
		System.out.println("7. 영수증 표시하기 \t8. 종료");
		System.out.println("9. 관리자 로그인");
		System.out.println("*************************");
	}


}