package com.market.cart;

import java.util.ArrayList;

import com.market.bookitem.Book;

public class Cart implements CartInterface {
	public ArrayList<CartItem> mCartItem = new ArrayList<CartItem>();
    public static int mCartCount = 0;

    public Cart() {
    }

    @Override
    public void printBookList(Book[] bookList) {
        for (Book book : bookList) {
            System.out.print(book.getBookId() + " | ");
            System.out.print(book.getName() + " | ");
            System.out.print(book.getUnitPrice() + " | ");
            System.out.print(book.getAuthor() + " | ");
            System.out.print(book.getDescription() + " | ");
            System.out.print(book.getCategory() + " | ");
            System.out.println(book.getReleaseDate());
        }
    }

    @Override
    public boolean isCartInBook(String bookId) {
        boolean flag = false;
        for (int i = 0; i < mCartCount; i++) {
            if (bookId.equals(mCartItem.get(i).getBookId())) { // 배열로 바꾸는 과정에서 [i] 의 문제 때문에 이를 해결하기 위해 AI 사용
                mCartItem.get(i).setQuantity(mCartItem.get(i).getQuantity() + 1);
                flag = true;
                break;
            }
        }
        return flag;
    }

    @Override
    public void insertBook(Book book) {
    	mCartItem.add(new CartItem(book));
    	mCartCount++;
    }

    @Override
    public void removeCart(int numId) {
    	mCartItem.remove(numId);
    	mCartCount--;
    }

    @Override
    public void deleteBook() {   
    	mCartItem.clear();
    	mCartCount = 0;
    }

    public void printCart() {
    	System.out.println("장바구니 상품 목록 :");
     	System.out.println("------------------------------------------------");
     	System.out.println("도서ID \t\t 수량 \t 합계");
     	
     	for (int i = 0; i < mCartCount; i++) {
            System.out.print(mCartItem.get(i).getBookId() + " \t ");
            System.out.print(mCartItem.get(i).getQuantity() + " \t ");
            System.out.println(mCartItem.get(i).getTotalPrice());
        }
        System.out.println("------------------------------------------------");
    }

    public int getTotalPrice() {
        int sum = 0;
        for (int i = 0; i < mCartCount; i++) {
            sum += mCartItem.get(i).getTotalPrice();
        }
        return sum;
    }
    public ArrayList<CartItem> getmCartItem() {
    	return mCartItem;
    }
    
    public void setmCartItem(ArrayList<CartItem> mCartItem) {
    	this.mCartItem = mCartItem;
    }
    
}
