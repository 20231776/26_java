package com.market.cart;

import com.market.bookitem.Book;

public class CartItem {
    private Book itemBook;
    private String bookId;
    private int quantity;
    private int totalPrice;

    public CartItem(Book book) {
        this.itemBook = book;
        this.bookId = book.getBookId();
        this.quantity = 1;
        updateTotalPrice();
    }

    public Book getItemBook() { return itemBook; }

    public void setItemBook(Book itemBook) {
        this.itemBook = itemBook;
        this.bookId = itemBook.getBookId();
        updateTotalPrice();
    }

    public String getBookId() { return bookId; }

    public void setBookId(String bookId) {
        this.bookId = bookId;
        updateTotalPrice();
    }

    public int getQuantity() { return quantity; }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        updateTotalPrice();
    }

    public int getTotalPrice() { return totalPrice; }

    public void updateTotalPrice() {
        if (itemBook != null) {
            totalPrice = itemBook.getUnitPrice() * quantity;
        }
    }
}
