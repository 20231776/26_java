package com.market.member;

public class User extends Person {
	
	
	public User(String name, String mobile) {
		super(name, mobile);
	}
	public User(String name, String mobile, String addr) {
		super(name, mobile, addr);
	}
	
	public static void main(String[] args) {
		
	}

}
