package com.market.member;

public class Person {

	private String name;
	private String mobile;
	private String addr;
	
	public Person(String name, String mobile) {
	
		this.name = name;
		this.mobile = mobile;
	}

	public Person(String name, String mobile, String addr) {
		
		this(name,mobile);
		this.addr = addr;
	}
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setPhone(String mobile) {
		this.mobile = mobile;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}


}
