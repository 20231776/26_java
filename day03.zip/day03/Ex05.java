package day03;
import java.util.Scanner;

public class Ex05 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("점수를 입력하세요 : ");
		int num = scan.nextInt();
		if (num >= 70) {
			
			//참일 때 실행문
			System.out.println("합격입니다.");
		}else {
			System.out.println("불합격입니다.");
		}
		
		scan.close();
	}

}
