package day05;
import java.util.Scanner;

public class Array02 {
	
public static void main(String[] args) {
		
		int intArray []; // 1차원 배열 선언
		intArray = new int [5]; // 배열 생성
		int sum = 0;

		Scanner scanner = new Scanner(System.in);
		System.out.println("양수 5개를 입력하세요.");
		for(int i = 0 ; i < intArray.length ; i++) {
			
			intArray [i] = scanner.nextInt();
			sum += intArray [i];
		}
		
		int average = sum / intArray.length;
		
		System.out.println("양수 합의 평균은 " + average + "입니다.");
		
		
		scanner.close();
			
		}
	}