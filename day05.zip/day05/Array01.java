package day05;
import java.util.Scanner;

public class Array01 {

	public static void main(String[] args) {
		
		int intArray []; // 1차원 배열 선언
		intArray = new int [5]; // 배열 생성
		int intMax = -1; // 가장 큰 수 저장
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("양수 5개를 입력하세요.");
		for(int i = 0 ; i < 5 ; i++) {
			
			intArray [i] = scanner.nextInt();
			if (intArray[i] > intMax) {
				intMax = intArray [i];
			}
			
		}
		System.out.println("가장 큰 수는 " + intMax + "입니다.");
		
		
		scanner.close();
	}

}
