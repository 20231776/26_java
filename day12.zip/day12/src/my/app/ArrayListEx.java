package my.app;
import java.util.Scanner;
import java.util.ArrayList;
public class ArrayListEx {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ArrayList<String> alist = new ArrayList<String>();
		
		for (int i = 0 ; i < 4 ; i++) {
			System.out.print("이름을 입력하세요 : ");
			alist.add(scanner.nextLine());
		}
		
		for (int i = 0 ; i < alist.size() ; i++) {
			String name = alist.get(i);
			System.out.print(name + " ");
		}
		
		
		scanner.close();
	}
}
