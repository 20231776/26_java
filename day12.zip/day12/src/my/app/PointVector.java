package my.app;
import java.util.Vector;

class Point {
	private int x, y;
	
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}


	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
}

public class PointVector {
	
public static void main(String[] args) {

	Vector<Point> pvectors = new Vector<Point>();
	pvectors.add(new Point(3,5));
	pvectors.add(new Point(30,70));

	
	for(int i = 0 ; i < pvectors.size() ; i++) {
		System.out.println("X:" +pvectors.elementAt(i).getX() + " Y:"+pvectors.elementAt(i).getY());
	}
	System.out.println(pvectors.elementAt(0).getX());
	System.out.println(pvectors.elementAt(1).getX());

	for(Point p:pvectors) {
		System.out.println(p.getX());
		System.out.println(p.getY());
	}
}

}
