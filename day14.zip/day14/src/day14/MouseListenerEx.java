package day14;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;

public class MouseListenerEx extends JFrame {

	JLabel lb;
	
	public MouseListenerEx() {
		Container con = getContentPane();
		con.setLayout(new FlowLayout());
		lb = new JLabel("hello");
		lb.setLocation(30, 30);
		lb.setSize(50, 60);
		con.add(lb);
		
		con.addMouseListener(new MyMouseListener());
		con.addMouseMotionListener(new MyMouseListener2());
		
		setSize(400,400);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
	
	
	
	class MyMouseListener extends MouseAdapter {
		public void mouseDragged(MouseEvent e) {
			int x = e.getX();
			int y = e.getY();
			lb.setLocation(x, y);
		}
	}
	class MyMouseListener2 extends MouseAdapter {
	public void mouseDragged(MouseEvent e) {

		lb.setText("MouseDragged (" + e.getX() + "," + e.getY()+")");

	}
	public void mouseMoved(MouseEvent e) {
		lb.setText("MouseMoved (" + e.getX() + "," + e.getY()+")");

	}
}
	public static void main(String[] args) {
		new MouseListenerEx();
	}
}