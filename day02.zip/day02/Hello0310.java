package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// print계열 메소드를 이용해 자바로 하고싶은 것 작성해서 출력 하기.
		System.out.println("포트폴리오를 웹사이트로 만들어 보고 싶습니다.");
		
	}
	

}
