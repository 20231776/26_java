package day11;

public class SmartPhone extends Calc implements PhoneInterface{

	public String toString() {
		return "Point(스마트폰 입니다)";
	}
	public static void main(String[] args) {
	SmartPhone sp = new SmartPhone();
	sp.sendCall();
	sp.receiveCall();
	System.out.println("3 + 5 = " + sp.calculate(3,5));
	System.out.println(sp.toString());
	}
	
	public void sendCall() {
		System.out.println("스마트폰 벨~~~");
	}
	
	public void receiveCall() {
		System.out.println("스마트폰 전화가 왔습니다.");
	}
}
