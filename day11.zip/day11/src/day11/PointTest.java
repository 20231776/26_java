package day11;
class Point {
	int x, y; // 정보 은닉

	public Point (int x, int y) {
		this.x = x;
		this.y = y;
		
	}

	// 인자생성자
public void setY(int y) {
	this.y = y;
}

public String toString() {
	return "Point("+ x + " ,"+ y + ")";
	
}
}

	// getter, setter

public class PointTest {

	public static void main(String[] args) {
		Point point = new Point(300,500);
		System.out.println(point.toString());
	}

}
