package day11;
import java.util.Random;
public class Lotto {

	public static void main(String[] args) {
		Random random = new Random();
		int[] n = new int[6];
		for (int i = 0; i < 6 ; i++) {
			n[i] = random.nextInt(45); 
		}
		System.out.print("이번주 로또 번호는 ");
		for (int i = 0; i < 6 ; i++) {
			System.out.print(n[i]+1 +" ");
		}
	}

}
